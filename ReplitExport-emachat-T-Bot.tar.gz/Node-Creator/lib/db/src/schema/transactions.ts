import {
  pgTable,
  bigint,
  text,
  numeric,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod/v4";

// ─── transactions ─────────────────────────────────────────────────────────────
// Immutable ledger of every balance change.
// Written by: deposit verification, game join (debit), game win (credit).
//
// user_id is BIGINT (Telegram user ID) matching profiles.id

export const transactionsTable = pgTable("transactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  // profiles.id is BIGINT — mode:"number" keeps it as a JS number (safe for Telegram IDs < 2^53)
  userId: bigint("user_id", { mode: "number" }).notNull(),
  // deposit | debit | win | refund | adjustment
  type: text("type").notNull(),
  // Positive for credits (deposit, win, refund), negative for debits
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  balanceBefore: numeric("balance_before", { precision: 12, scale: 2 }),
  balanceAfter: numeric("balance_after", { precision: 12, scale: 2 }),
  // Human-readable description for the user's transaction history screen
  description: text("description"),
  // Links back to the source: pending_deposit.id, game_id, etc.
  referenceId: text("reference_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTransactionSchema = createInsertSchema(
  transactionsTable,
).omit({ id: true, createdAt: true });

export const selectTransactionSchema = createSelectSchema(transactionsTable);

export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactionsTable.$inferSelect;
