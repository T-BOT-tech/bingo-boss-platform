import {
  pgTable,
  bigint,
  text,
  numeric,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";
import { z } from "zod/v4";

// ─── pending_deposits ─────────────────────────────────────────────────────────
// Tracks Telebirr / CBE / M-Pesa manual deposit requests before admin verification.
// Flow: user submits amount + method → record created with unique reference_code
//       → user makes bank transfer quoting the reference_code
//       → admin verifies and flips status to 'verified' → balance credited
//
// user_id is BIGINT (Telegram user ID) matching profiles.id

export const pendingDepositsTable = pgTable("pending_deposits", {
  id: uuid("id").primaryKey().defaultRandom(),
  // profiles.id is BIGINT — mode:"number" keeps it as a JS number (safe for Telegram IDs < 2^53)
  userId: bigint("user_id", { mode: "number" }).notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  // Payment method — expand as new rails are added
  method: text("method").notNull(), // 'telebirr' | 'cbe' | 'mpesa'
  // Server-generated code shown to the user; they quote it in their transfer
  referenceCode: text("reference_code").notNull().unique(),
  // What the user submitted back for verification (TX ID or bank SMS)
  submittedReference: text("submitted_reference"),
  // Optional screenshot URL (stored in object storage)
  screenshotUrl: text("screenshot_url"),
  // pending → awaiting_review → verified | rejected
  status: text("status").notNull().default("pending"),
  // Admin note (rejection reason, etc.)
  notes: text("notes"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  verifiedAt: timestamp("verified_at"),
});

export const insertPendingDepositSchema = createInsertSchema(
  pendingDepositsTable,
).omit({ id: true, createdAt: true, verifiedAt: true });

export const selectPendingDepositSchema =
  createSelectSchema(pendingDepositsTable);

export type InsertPendingDeposit = z.infer<typeof insertPendingDepositSchema>;
export type PendingDeposit = typeof pendingDepositsTable.$inferSelect;
