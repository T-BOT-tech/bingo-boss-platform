-- ─────────────────────────────────────────────────────────────────────────────
-- Bingo ETB — Supabase Schema
-- Run this once in your Supabase project → SQL Editor → New query → Run
-- ─────────────────────────────────────────────────────────────────────────────

-- ── 1. profiles ──────────────────────────────────────────────────────────────
-- Each row is one Telegram user. id = Telegram user_id (stored as text).
-- Created automatically on first launch via authMiddleware upsert.

create table if not exists public.profiles (
  id            text primary key,            -- Telegram user_id
  first_name    text,
  username      text,
  balance_etb   numeric(12, 2) not null default 0,
  created_at    timestamptz not null default now()
);

-- ── 2. game_history ───────────────────────────────────────────────────────────
-- One row per winning card per game. Written by the Monitor on BINGO detection.

create table if not exists public.game_history (
  id            uuid primary key default gen_random_uuid(),
  user_id       text not null references public.profiles(id),
  room          text not null,               -- '10etb' | '5etb'
  game_id       text not null,
  card_id       integer not null,
  amount_won    numeric(12, 2) not null,      -- this card's share of prize
  total_won     numeric(12, 2) not null,      -- total won by this user in game
  is_split      boolean not null default false,
  winner_count  integer not null default 1,
  created_at    timestamptz not null default now()
);

create index if not exists game_history_user_id_idx on public.game_history(user_id);
create index if not exists game_history_game_id_idx  on public.game_history(game_id);

-- ── 3. transactions ───────────────────────────────────────────────────────────
-- Immutable ledger. Every balance change writes a row here.
-- type: 'debit' | 'win' | 'deposit' | 'refund' | 'adjustment'

create table if not exists public.transactions (
  id              uuid primary key default gen_random_uuid(),
  user_id         text not null references public.profiles(id),
  type            text not null,
  amount          numeric(12, 2) not null,   -- positive = credit, negative = debit
  balance_before  numeric(12, 2),
  balance_after   numeric(12, 2),
  description     text,
  reference_id    text,                      -- game_id, deposit_id, etc.
  created_at      timestamptz not null default now()
);

create index if not exists transactions_user_id_idx on public.transactions(user_id);
create index if not exists transactions_type_idx    on public.transactions(type);

-- ── 4. pending_deposits ───────────────────────────────────────────────────────
-- Tracks Telebirr / CBE / M-Pesa manual deposit requests.
-- Status flow:  pending → awaiting_review → verified | rejected

create table if not exists public.pending_deposits (
  id                   uuid primary key default gen_random_uuid(),
  user_id              text not null references public.profiles(id),
  amount               numeric(12, 2) not null,
  method               text not null,        -- 'telebirr' | 'cbe' | 'mpesa'
  reference_code       text not null unique, -- 'BINGO-XXXXXX'
  submitted_reference  text,                 -- TX ID or SMS the user pasted
  screenshot_url       text,
  status               text not null default 'pending',
  notes                text,
  created_at           timestamptz not null default now(),
  verified_at          timestamptz
);

create index if not exists pending_deposits_user_id_idx on public.pending_deposits(user_id);
create index if not exists pending_deposits_status_idx  on public.pending_deposits(status);

-- ── 5. deduct_balance RPC ─────────────────────────────────────────────────────
-- Called by POST /api/join-game. Atomically deducts the stake and raises an
-- exception if the user has insufficient balance (preventing negative balances).

create or replace function public.deduct_balance(
  p_user_id text,
  p_amount  numeric
)
returns void
language plpgsql
security definer
as $$
begin
  update public.profiles
  set    balance_etb = balance_etb - p_amount
  where  id = p_user_id
    and  balance_etb >= p_amount;

  if not found then
    raise exception 'Insufficient balance or user not found (user_id: %, amount: %)',
      p_user_id, p_amount;
  end if;
end;
$$;
