#!/usr/bin/env bash
# ─── Bingo ETB Backend — Full Smoke Test ──────────────────────────────────────
# Usage: bash artifacts/api-server/scripts/smoke-test.sh
# Requires: curl, jq

BASE="http://localhost:80/api"
PASS=0
FAIL=0

# Colour codes
GRN='\033[0;32m'
RED='\033[0;31m'
YLW='\033[1;33m'
NC='\033[0m'

check() {
  local label="$1"
  local expected_status="$2"
  local actual_status="$3"
  local body="$4"

  if [[ "$actual_status" == "$expected_status" ]]; then
    echo -e "${GRN}✓${NC} $label (HTTP $actual_status)"
    ((PASS++))
  else
    echo -e "${RED}✗${NC} $label — expected $expected_status got $actual_status"
    echo "  Body: $body" | head -c 200
    echo ""
    ((FAIL++))
  fi
}

sep() { echo -e "\n${YLW}── $1 ──${NC}"; }

# ─── 1. Infrastructure ────────────────────────────────────────────────────────
sep "Infrastructure"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" "$BASE/healthz")
check "GET /healthz" "200" "$R" "$(cat /tmp/st_body)"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" "$BASE/heartbeat")
check "GET /heartbeat" "200" "$R" "$(cat /tmp/st_body)"

# ─── 2. Auth guard ────────────────────────────────────────────────────────────
sep "Auth guard (no initData → 401)"

for ENDPOINT in "room-status/10etb" "user/profile" "user/transactions" "wallet/deposit"; do
  METHOD="GET"
  [[ "$ENDPOINT" == "wallet/deposit" ]] && METHOD="POST"
  R=$(curl -s -o /tmp/st_body -w "%{http_code}" -X $METHOD "$BASE/$ENDPOINT")
  check "$METHOD /$ENDPOINT blocked" "401" "$R" "$(cat /tmp/st_body)"
done

# ─── 3. Room status (no auth → 401) ──────────────────────────────────────────
sep "Room status"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" "$BASE/room-status/10etb")
check "GET /room-status/10etb blocked" "401" "$R" "$(cat /tmp/st_body)"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" "$BASE/room-status/badroom")
check "GET /room-status/badroom → 401 (auth first)" "401" "$R" "$(cat /tmp/st_body)"

# ─── 4. Bot webhook ───────────────────────────────────────────────────────────
sep "Telegram Bot"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" \
  -X POST "$BASE/bot/webhook" \
  -H "Content-Type: application/json" \
  -d '{"update_id":999}')
check "POST /bot/webhook (no message) → 200" "200" "$R" "$(cat /tmp/st_body)"

# ─── 5. Admin guard ───────────────────────────────────────────────────────────
sep "Admin guard"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" "$BASE/admin/deposits/pending")
check "GET /admin/deposits/pending (no secret) → 403" "403" "$R" "$(cat /tmp/st_body)"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" \
  -H "X-Admin-Secret: wrongsecret" \
  "$BASE/admin/deposits/pending")
check "GET /admin/deposits/pending (wrong secret) → 403" "403" "$R" "$(cat /tmp/st_body)"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" "$BASE/admin/stats")
check "GET /admin/stats (no secret) → 403" "403" "$R" "$(cat /tmp/st_body)"

# ─── 6. Admin endpoints (valid secret) ────────────────────────────────────────
sep "Admin endpoints (valid ADMIN_SECRET)"

ADMIN_SECRET="${ADMIN_SECRET:-}"
if [[ -z "$ADMIN_SECRET" ]]; then
  echo -e "${YLW}⚠ ADMIN_SECRET env var not exported to shell — skipping live admin tests${NC}"
else
  R=$(curl -s -o /tmp/st_body -w "%{http_code}" \
    -H "X-Admin-Secret: $ADMIN_SECRET" \
    "$BASE/admin/deposits/pending")
  check "GET /admin/deposits/pending (valid secret)" "200" "$R" "$(cat /tmp/st_body)"

  R=$(curl -s -o /tmp/st_body -w "%{http_code}" \
    -H "X-Admin-Secret: $ADMIN_SECRET" \
    "$BASE/admin/stats")
  check "GET /admin/stats (valid secret)" "200" "$R" "$(cat /tmp/st_body)"

  # Verify admin/stats response shape
  STATS_BODY=$(cat /tmp/st_body)
  if echo "$STATS_BODY" | jq -e '.stats.total_user_balance_etb != null or .stats.live_rooms' > /dev/null 2>&1; then
    echo -e "${GRN}✓${NC} /admin/stats response has expected shape"
    ((PASS++))
  else
    echo -e "${RED}✗${NC} /admin/stats response shape unexpected: $STATS_BODY"
    ((FAIL++))
  fi
fi

# ─── 7. Wallet deposit input validation ───────────────────────────────────────
sep "Wallet deposit input validation (via auth guard)"

# Without auth these all return 401 — that's the correct first barrier
R=$(curl -s -o /tmp/st_body -w "%{http_code}" \
  -X POST "$BASE/wallet/deposit" \
  -H "Content-Type: application/json" \
  -d '{"provider":"invalid","amount":50}')
check "POST /wallet/deposit (no auth) → 401" "401" "$R" "$(cat /tmp/st_body)"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" \
  -X POST "$BASE/wallet/deposit/submit" \
  -H "Content-Type: application/json" \
  -d '{"deposit_id":"test"}')
check "POST /wallet/deposit/submit (no auth) → 401" "401" "$R" "$(cat /tmp/st_body)"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" \
  -X POST "$BASE/wallet/deposit/verify" \
  -H "Content-Type: application/json" \
  -d '{"deposit_id":"test","action":"approve"}')
check "POST /wallet/deposit/verify (no admin secret) → 403" "403" "$R" "$(cat /tmp/st_body)"

# ─── 8. Join game input validation ────────────────────────────────────────────
sep "Join game input validation"

R=$(curl -s -o /tmp/st_body -w "%{http_code}" \
  -X POST "$BASE/join-game" \
  -H "Content-Type: application/json" \
  -d '{"room":"10etb","cardIds":[1,2]}')
check "POST /join-game (no auth) → 401" "401" "$R" "$(cat /tmp/st_body)"

# ─── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo "────────────────────────────────────────"
TOTAL=$((PASS + FAIL))
if [[ $FAIL -eq 0 ]]; then
  echo -e "${GRN}All $TOTAL tests passed ✓${NC}"
else
  echo -e "${RED}$FAIL/$TOTAL tests FAILED${NC}"
fi
echo "────────────────────────────────────────"
exit $FAIL
