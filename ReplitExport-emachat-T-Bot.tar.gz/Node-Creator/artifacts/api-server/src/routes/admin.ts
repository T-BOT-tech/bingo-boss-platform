import { Router, type IRouter } from "express";
import { supabase } from "../lib/supabase";
import { adminMiddleware } from "../middleware/adminMiddleware";
import { getRoomMeta, type RoomId } from "../services/roomManager";

const router: IRouter = Router();

// ─── GET /api/admin/deposits/pending ─────────────────────────────────────────
// Returns every deposit currently sitting at awaiting_review, newest first.

router.get("/admin/deposits/pending", adminMiddleware, async (req, res) => {
  try {
    const { data: deposits, error } = await supabase
      .from("pending_deposits")
      .select(
        "id, user_id, amount, method, reference_code, submitted_reference, notes, created_at",
      )
      .eq("status", "awaiting_review")
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);

    res.status(200).json({
      success: true,
      count: deposits?.length ?? 0,
      deposits: (deposits ?? []).map((d) => ({
        deposit_id: d.id,
        user_id: d.user_id,
        amount: d.amount,
        provider: d.method,
        reference_code: d.reference_code,
        // "proof_text" is whatever the user pasted — could be a TX ID or SMS
        proof_text: d.submitted_reference ?? null,
        submitted_at: d.created_at,
      })),
    });
  } catch (err: unknown) {
    req.log.error({ err }, "admin/deposits/pending failed");
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ success: false, error: message });
  }
});

// ─── GET /api/admin/stats ─────────────────────────────────────────────────────
// Aggregated platform snapshot.
//
// Commissions math (from roomManager):
//   winner_prize = pot × 0.8  →  commission = pot × 0.2 = winner_prize × 0.25
//   All "win" transactions in the ledger represent paid-out winner prizes, so:
//   total_commissions = SUM(win transactions) × 0.25

router.get("/admin/stats", adminMiddleware, async (req, res) => {
  try {
    const [balancesRes, winsRes, depositCountRes, pendingDepRes] =
      await Promise.allSettled([
        // 1. Sum of every user's current balance
        supabase.from("profiles").select("balance_etb"),

        // 2. Sum of all "win" transactions → derive commission
        supabase
          .from("transactions")
          .select("amount")
          .eq("type", "win"),

        // 3. Total deposit transactions processed
        supabase
          .from("transactions")
          .select("*", { count: "exact", head: true })
          .eq("type", "deposit"),

        // 4. Count of deposits still awaiting review
        supabase
          .from("pending_deposits")
          .select("*", { count: "exact", head: true })
          .eq("status", "awaiting_review"),
      ]);

    // Total ETB held across all user wallets
    const totalUserBalance =
      balancesRes.status === "fulfilled" && balancesRes.value.data
        ? balancesRes.value.data.reduce(
            (sum, row) => sum + Number(row.balance_etb ?? 0),
            0,
          )
        : null;

    // Sum of all win payouts; commission = that × 0.25
    const totalWinsPaid =
      winsRes.status === "fulfilled" && winsRes.value.data
        ? winsRes.value.data.reduce(
            (sum, row) => sum + Number(row.amount ?? 0),
            0,
          )
        : null;

    const totalCommissions =
      totalWinsPaid !== null
        ? parseFloat((totalWinsPaid * 0.25).toFixed(2))
        : null;

    const totalDepositsProcessed =
      depositCountRes.status === "fulfilled"
        ? (depositCountRes.value.count ?? 0)
        : null;

    const pendingDepositCount =
      pendingDepRes.status === "fulfilled"
        ? (pendingDepRes.value.count ?? 0)
        : null;

    // Live room states from Redis — don't fail the whole request if Redis is slow
    const roomIds: RoomId[] = ["10etb", "5etb"];
    const roomSnapshots = await Promise.all(
      roomIds.map(async (room) => {
        try {
          const meta = await getRoomMeta(room);
          return {
            room,
            status: meta ? "active" : "idle",
            card_count: meta?.card_count ?? 0,
            pot: meta?.pot ?? 0,
            winner_prize: meta?.winner_prize ?? 0,
            game_id: meta?.game_id ?? null,
          };
        } catch {
          return { room, status: "unknown", card_count: 0, pot: 0, winner_prize: 0, game_id: null };
        }
      }),
    );

    res.status(200).json({
      success: true,
      stats: {
        total_user_balance_etb: totalUserBalance,
        total_commissions_etb: totalCommissions,
        total_win_payouts_etb:
          totalWinsPaid !== null
            ? parseFloat(totalWinsPaid.toFixed(2))
            : null,
        total_deposits_processed: totalDepositsProcessed,
        pending_deposit_reviews: pendingDepositCount,
      },
      live_rooms: roomSnapshots,
    });
  } catch (err: unknown) {
    req.log.error({ err }, "admin/stats failed");
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ success: false, error: message });
  }
});

export default router;
