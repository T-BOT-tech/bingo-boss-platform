import { Router, type IRouter } from "express";
import healthRouter from "./health";
import heartbeatRouter from "./heartbeat";
import gameRouter from "./game";
import roomStatusRouter from "./roomStatus";
import botRouter from "./bot";
import userRouter from "./user";
import walletRouter from "./wallet";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(heartbeatRouter);
router.use(botRouter);
router.use(gameRouter);
router.use(roomStatusRouter);
router.use(userRouter);
router.use(walletRouter);
router.use(adminRouter);

export default router;
