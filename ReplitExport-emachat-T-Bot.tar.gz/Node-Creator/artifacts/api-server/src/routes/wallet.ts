import { Router, type IRouter } from "express";
import { randomInt } from "crypto";
import { supabase } from "../lib/supabase";
import { authMiddleware } from "../middleware/authMiddleware";
import { adminMiddleware } from "../middleware/adminMiddleware";
import { getIO } from "../lib/socket";
import { logger } from "../lib/logger";

const router: IRouter = Router();

// ─── Supported providers ──────────────────────────────────────────────────────

type Provider = "telebirr" | "cbe" | "mpesa";

const PROVIDERS: Provider[] = ["telebirr", "cbe", "mpesa"];

// Payment destination per provider — set these in your environment variables.
// Defaults are shown here as placeholders so the server starts without them.
function getPaymentDestination(provider: Provider): string {
  switch (provider) {
    case "telebirr":
      return process.env["TELEBIRR_NUMBER"] ?? "0912-XXX-XXXX (set TELEBIRR_NUMBER)";
    case "cbe":
      return process.env["CBE_ACCOUNT"] ?? "1000-XXXXXXX-XX (set CBE_ACCOUNT)";
    case "mpesa":
      return process.env["MPESA_NUMBER"] ?? "0712-XXX-XXXX (set MPESA_NUMBER)";
  }
}

function buildInstructions(provider: Provider, refCode: string, amount: number): string {
  const dest = getPaymentDestination(provider);
  switch (provider) {
    case "telebirr":
      return (
        `Send ${amount} ETB via Telebirr to ${dest}. ` +
        `In the reason/description field enter exactly: ${refCode}. ` +
        `Once sent, paste your confirmation SMS below.`
      );
    case "cbe":
      return (
        `Transfer ${amount} ETB via CBE Mobile/Internet Banking to account ${dest}. ` +
        `In the remark field enter exactly: ${refCode}. ` +
        `Once completed, paste your transaction ID or confirmation SMS below.`
      );
    case "mpesa":
      return (
        `Send ${amount} ETB via M-Pesa to ${dest}. ` +
        `In the reason/description field enter exactly: ${refCode}. ` +
        `Once sent, paste your confirmation SMS below.`
      );
  }
}

// ─── Reference code ───────────────────────────────────────────────────────────
// BINGO-XXXXXX — 6 cryptographically random digits, guaranteed unique.

async function generateUniqueRefCode(): Promise<string> {
  for (let attempt = 0; attempt < 10; attempt++) {
    const digits = String(randomInt(0, 999999)).padStart(6, "0");
    const code = `BINGO-${digits}`;
    const { data } = await supabase
      .from("pending_deposits")
      .select("id")
      .eq("reference_code", code)
      .maybeSingle();
    if (!data) return code; // No collision — safe to use
  }
  throw new Error("Could not generate a unique reference code after 10 attempts");
}

// ─── POST /api/wallet/deposit ─────────────────────────────────────────────────
// Step 1: user picks a provider and amount → gets a reference code + instructions.

router.post("/wallet/deposit", authMiddleware, async (req, res) => {
  // BIGINT — keep as number for Supabase; template literal converts for logs/Redis
  const userId = req.telegramUser.id;
  const { provider, amount } = req.body as { provider: string; amount: number };

  // Input validation
  if (!PROVIDERS.includes(provider as Provider)) {
    res.status(400).json({
      success: false,
      error: `provider must be one of: ${PROVIDERS.join(", ")}`,
    });
    return;
  }
  const parsedAmount = Number(amount);
  if (!parsedAmount || parsedAmount < 10 || parsedAmount > 10000) {
    res.status(400).json({
      success: false,
      error: "amount must be between 10 and 10,000 ETB",
    });
    return;
  }

  try {
    // Safety: cap pending deposits per user to prevent spam
    const { count: pendingCount } = await supabase
      .from("pending_deposits")
      .select("*", { count: "exact", head: true })
      .eq("user_id", userId)
      .in("status", ["pending", "awaiting_review"]);

    if ((pendingCount ?? 0) >= 3) {
      res.status(429).json({
        success: false,
        error:
          "You already have 3 pending deposit requests. " +
          "Please wait for them to be reviewed before submitting a new one.",
      });
      return;
    }

    const refCode = await generateUniqueRefCode();

    const { data: deposit, error: insertErr } = await supabase
      .from("pending_deposits")
      .insert({
        user_id: userId,
        amount: parsedAmount,
        method: provider,
        reference_code: refCode,
        status: "pending",
      })
      .select("id, reference_code, amount, method, status, created_at")
      .single();

    if (insertErr || !deposit) {
      throw new Error(insertErr?.message ?? "Failed to create deposit record");
    }

    req.log.info({ userId, provider, amount: parsedAmount, refCode }, "Deposit request created");

    res.status(201).json({
      success: true,
      deposit_id: deposit.id,
      reference_code: refCode,
      amount: parsedAmount,
      provider,
      instructions: buildInstructions(provider as Provider, refCode, parsedAmount),
    });
  } catch (err: unknown) {
    req.log.error({ err }, "wallet/deposit failed");
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ success: false, error: message });
  }
});

// ─── POST /api/wallet/deposit/submit ─────────────────────────────────────────
// Step 2: user pastes their transaction ID or bank SMS proof.
// Marks the deposit as awaiting_review so an admin can verify it.

router.post("/wallet/deposit/submit", authMiddleware, async (req, res) => {
  // BIGINT number for Supabase; Supabase returns user_id as string → compare via Number()
  const userId = req.telegramUser.id;
  const { deposit_id, transaction_id, sms_text } = req.body as {
    deposit_id: string;
    transaction_id?: string;
    sms_text?: string;
  };

  if (!deposit_id) {
    res.status(400).json({ success: false, error: "deposit_id is required" });
    return;
  }

  const submittedReference = transaction_id ?? sms_text;
  if (!submittedReference || submittedReference.trim().length < 3) {
    res.status(400).json({
      success: false,
      error: "Provide either transaction_id or sms_text as proof",
    });
    return;
  }

  try {
    // Ensure the deposit belongs to this user and is still in 'pending' state
    const { data: existing, error: fetchErr } = await supabase
      .from("pending_deposits")
      .select("id, status, user_id")
      .eq("id", deposit_id)
      .maybeSingle();

    if (fetchErr || !existing) {
      res.status(404).json({ success: false, error: "Deposit not found" });
      return;
    }
    // Supabase returns BIGINT columns as strings → normalise both sides to Number
    if (Number(existing.user_id) !== userId) {
      res.status(403).json({ success: false, error: "Forbidden" });
      return;
    }
    if (existing.status !== "pending") {
      res.status(409).json({
        success: false,
        error: `Deposit is already in '${existing.status}' status`,
      });
      return;
    }

    const { error: updateErr } = await supabase
      .from("pending_deposits")
      .update({
        submitted_reference: submittedReference.trim(),
        status: "awaiting_review",
      })
      .eq("id", deposit_id);

    if (updateErr) throw new Error(updateErr.message);

    req.log.info({ userId, deposit_id }, "Deposit proof submitted");

    res.status(200).json({
      success: true,
      status: "awaiting_review",
      message: "Your proof has been submitted. An admin will verify it shortly.",
    });
  } catch (err: unknown) {
    req.log.error({ err }, "wallet/deposit/submit failed");
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ success: false, error: message });
  }
});

// ─── POST /api/wallet/deposit/verify ─────────────────────────────────────────
// Step 3: Admin approves or rejects a deposit.
// Protected by X-Admin-Secret header.

router.post("/wallet/deposit/verify", adminMiddleware, async (req, res) => {
  const { deposit_id, action, notes } = req.body as {
    deposit_id: string;
    action: "approve" | "reject";
    notes?: string;
  };

  if (!deposit_id) {
    res.status(400).json({ success: false, error: "deposit_id is required" });
    return;
  }
  if (action !== "approve" && action !== "reject") {
    res.status(400).json({ success: false, error: "action must be 'approve' or 'reject'" });
    return;
  }

  try {
    // Fetch the deposit record
    const { data: deposit, error: fetchErr } = await supabase
      .from("pending_deposits")
      .select("id, user_id, amount, method, status, reference_code")
      .eq("id", deposit_id)
      .maybeSingle();

    if (fetchErr || !deposit) {
      res.status(404).json({ success: false, error: "Deposit not found" });
      return;
    }
    if (deposit.status !== "awaiting_review") {
      res.status(409).json({
        success: false,
        error: `Deposit is in '${deposit.status}' status — only 'awaiting_review' deposits can be actioned`,
      });
      return;
    }

    const now = new Date().toISOString();

    if (action === "reject") {
      await supabase
        .from("pending_deposits")
        .update({ status: "rejected", notes: notes ?? null, verified_at: now })
        .eq("id", deposit_id);

      logger.info({ deposit_id, userId: deposit.user_id }, "Deposit rejected by admin");

      res.status(200).json({
        success: true,
        action: "rejected",
        deposit_id,
        notes: notes ?? null,
      });
      return;
    }

    // ── Approve flow ──────────────────────────────────────────────────────────

    const creditAmount = Number(deposit.amount);
    // deposit.user_id is returned as a string by Supabase (BIGINT → JSON string).
    // Parse to number for Supabase BIGINT equality queries and Socket.io room naming.
    const userId = Number(deposit.user_id);

    // Read current balance
    const { data: profile } = await supabase
      .from("profiles")
      .select("balance_etb")
      .eq("id", userId)
      .single();

    const balanceBefore = Number(profile?.balance_etb ?? 0);
    const balanceAfter = balanceBefore + creditAmount;

    // Credit balance
    const { error: balanceErr } = await supabase
      .from("profiles")
      .update({ balance_etb: balanceAfter })
      .eq("id", userId);

    if (balanceErr) throw new Error(balanceErr.message);

    // Write deposit ledger record
    await supabase.from("transactions").insert({
      user_id: userId,
      type: "deposit",
      amount: creditAmount,
      balance_before: balanceBefore,
      balance_after: balanceAfter,
      description: `Deposit via ${deposit.method} (ref: ${deposit.reference_code})`,
      reference_id: deposit_id,
      created_at: now,
    });

    // Mark deposit as verified
    await supabase
      .from("pending_deposits")
      .update({ status: "verified", notes: notes ?? null, verified_at: now })
      .eq("id", deposit_id);

    // Push real-time balance update to the user's connected device
    try {
      getIO().to(`user:${userId}`).emit("balance_update", {
        type: "balance_update",
        userId,
        balance_etb: balanceAfter,
        delta: creditAmount,
        reason: "deposit",
        method: deposit.method,
        timestamp: Date.now(),
      });
    } catch (sockErr) {
      logger.warn({ sockErr, userId }, "balance_update emit failed after deposit approval");
    }

    logger.info(
      { deposit_id, userId, creditAmount, balanceAfter },
      "Deposit approved by admin",
    );

    res.status(200).json({
      success: true,
      action: "approved",
      deposit_id,
      user_id: userId,
      credited_amount: creditAmount,
      new_balance: balanceAfter,
    });
  } catch (err: unknown) {
    logger.error({ err }, "wallet/deposit/verify failed");
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ success: false, error: message });
  }
});

export default router;
