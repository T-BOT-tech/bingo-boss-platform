import { Router, type IRouter } from "express";
import { supabase } from "../lib/supabase";
import { authMiddleware } from "../middleware/authMiddleware";
import {
  getOrInitRoom,
  registerJoin,
  validateCardsForBatch,
  type RoomId,
} from "../services/roomManager";

const router: IRouter = Router();

const VALID_ROOMS: RoomId[] = ["10etb", "5etb"];
const STAKE: Record<RoomId, number> = { "10etb": 10, "5etb": 5 };

router.post("/join-game", authMiddleware, async (req, res) => {
  // telegramId (number) → used for all Supabase queries (profiles.id is BIGINT).
  // userIdStr (string) → used for Redis keys and roomManager (Redis is string-only).
  const telegramId = req.telegramUser.id;
  const userIdStr = String(telegramId);

  const { room, cardIds } = req.body as {
    room: string;
    cardIds: number[];
  };

  // ── Input validation ──────────────────────────────────────────────────────
  if (!VALID_ROOMS.includes(room as RoomId)) {
    res.status(400).json({
      success: false,
      error: `room must be one of: ${VALID_ROOMS.join(", ")}`,
    });
    return;
  }
  if (!Array.isArray(cardIds) || cardIds.length === 0 || cardIds.length > 3) {
    res.status(400).json({
      success: false,
      error: "cardIds must be an array of 1–3 card IDs",
    });
    return;
  }

  const typedRoom = room as RoomId;
  const stake = STAKE[typedRoom];
  const totalCost = stake * cardIds.length;

  try {
    // 1. Get or initialise the room (assigns a clean batch if new)
    const roomMeta = await getOrInitRoom(typedRoom);

    // 2. Validate all cards belong to this room's current batch
    if (!validateCardsForBatch(cardIds, roomMeta.batch_id)) {
      res.status(400).json({
        success: false,
        error: `All cards must be from Batch ${roomMeta.batch_id} for the ${room} room`,
        allowedBatch: roomMeta.batch_id,
      });
      return;
    }

    // 3. Atomic balance deduction via Supabase RPC (p_user_id is BIGINT)
    const { error: txError } = await supabase.rpc("deduct_balance", {
      p_user_id: telegramId,
      p_amount: totalCost,
    });
    if (txError) throw new Error(txError.message);

    // 4. Fetch updated balance (RPC returns void)
    const { data: profile } = await supabase
      .from("profiles")
      .select("balance_etb")
      .eq("id", telegramId)
      .single();

    // 5. Register player + cards in Redis (uses string key internally)
    const { card_count, pot, winner_prize } = await registerJoin(
      typedRoom,
      userIdStr,
      cardIds,
      stake,
    );

    // 6. Write an immutable debit record to the ledger (fire-and-forget; non-fatal)
    supabase
      .from("transactions")
      .insert({
        user_id: telegramId,  // BIGINT — pass number, not string
        type: "debit",
        amount: -totalCost,
        balance_after: profile?.balance_etb ?? null,
        description: `Entry fee: ${cardIds.length} card(s) in ${room} room (Batch ${roomMeta.batch_id})`,
        reference_id: roomMeta.game_id ?? null,
        created_at: new Date().toISOString(),
      })
      .then(({ error }) => {
        if (error) req.log.warn({ error }, "Debit transaction insert failed");
      });

    req.log.info(
      { room, telegramId, cardIds, pot, winner_prize },
      "Player joined game",
    );

    res.status(200).json({
      success: true,
      newBalance: profile?.balance_etb,
      batchId: roomMeta.batch_id,
      cardCount: card_count,
      pot,
      winnerPrize: winner_prize,
      message: `Joined ${room} with ${cardIds.length} card(s) from Batch ${roomMeta.batch_id}`,
    });
  } catch (err: unknown) {
    req.log.error({ err }, "join-game failed");
    const message = err instanceof Error ? err.message : String(err);
    res.status(400).json({ success: false, error: message });
  }
});

export default router;
