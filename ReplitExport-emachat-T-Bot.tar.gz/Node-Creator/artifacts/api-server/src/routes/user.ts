import { Router, type IRouter } from "express";
import { supabase } from "../lib/supabase";
import { authMiddleware } from "../middleware/authMiddleware";

const router: IRouter = Router();

// ─── GET /api/user/profile ────────────────────────────────────────────────────

router.get("/user/profile", authMiddleware, async (req, res) => {
  // profiles.id is BIGINT — use the numeric Telegram ID directly
  const userId = req.telegramUser.id;

  try {
    // Fetch balance + name from profiles
    const { data: profile, error: profErr } = await supabase
      .from("profiles")
      .select("balance_etb, first_name, username")
      .eq("id", userId)
      .single();

    if (profErr || !profile) {
      res.status(404).json({ success: false, error: "Profile not found" });
      return;
    }

    // Count total games played and wins from the transactions ledger.
    // Both queries run in parallel; fallback to 0 if tables are not yet migrated.
    const [gamesResult, winsResult] = await Promise.allSettled([
      supabase
        .from("transactions")
        .select("*", { count: "exact", head: true })
        .eq("user_id", userId)
        .eq("type", "debit"),
      supabase
        .from("transactions")
        .select("*", { count: "exact", head: true })
        .eq("user_id", userId)
        .eq("type", "win"),
    ]);

    const totalGamesPlayed =
      gamesResult.status === "fulfilled" ? (gamesResult.value.count ?? 0) : 0;
    const totalWins =
      winsResult.status === "fulfilled" ? (winsResult.value.count ?? 0) : 0;

    res.status(200).json({
      success: true,
      profile: {
        userId: userId,  // number — matches BIGINT PK
        first_name: profile.first_name ?? req.telegramUser.first_name,
        username: profile.username ?? req.telegramUser.username ?? null,
        balance_etb: profile.balance_etb ?? 0,
        total_games_played: totalGamesPlayed,
        total_wins: totalWins,
      },
    });
  } catch (err: unknown) {
    req.log.error({ err }, "user/profile failed");
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ success: false, error: message });
  }
});

// ─── GET /api/user/transactions ───────────────────────────────────────────────
// Returns a unified, time-ordered ledger of all balance changes:
//   debit   — entry fee paid when joining a game
//   win     — prize credited after a bingo
//   deposit — manual top-up (Telebirr / CBE)
//   refund  — any admin-issued refund

router.get("/user/transactions", authMiddleware, async (req, res) => {
  // BIGINT column — pass number, not string
  const userId = req.telegramUser.id;

  // Optional ?limit= and ?offset= query params for pagination
  const limit = Math.min(parseInt((req.query["limit"] as string) ?? "30"), 100);
  const offset = parseInt((req.query["offset"] as string) ?? "0");

  try {
    const { data: txs, error: txErr } = await supabase
      .from("transactions")
      .select(
        "id, type, amount, balance_before, balance_after, description, reference_id, created_at",
      )
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);

    if (txErr) throw new Error(txErr.message);

    // Also pull pending deposit requests so the user can see their deposit status
    const { data: deposits } = await supabase
      .from("pending_deposits")
      .select(
        "id, amount, method, reference_code, submitted_reference, status, created_at, verified_at",
      )
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(20);

    res.status(200).json({
      success: true,
      transactions: txs ?? [],
      pending_deposits: deposits ?? [],
    });
  } catch (err: unknown) {
    req.log.error({ err }, "user/transactions failed");
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ success: false, error: message });
  }
});

export default router;
