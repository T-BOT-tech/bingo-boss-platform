import { Router, type IRouter, type Request, type Response } from "express";
import { logger } from "../lib/logger";

// ─── Types (minimal subset of Telegram Bot API) ───────────────────────────────

interface TelegramMessage {
  message_id: number;
  chat: { id: number; type: string };
  from?: { id: number; first_name: string; username?: string };
  text?: string;
}

interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
}

// ─── Telegram Bot API helper ──────────────────────────────────────────────────

async function sendMessage(
  chatId: number,
  text: string,
  replyMarkup?: Record<string, unknown>,
): Promise<void> {
  const botToken = process.env["BOT_TOKEN"];
  if (!botToken) {
    logger.error("BOT_TOKEN is not set — cannot send Telegram message");
    return;
  }

  const body: Record<string, unknown> = {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
  };
  if (replyMarkup) body.reply_markup = replyMarkup;

  const res = await fetch(
    `https://api.telegram.org/bot${botToken}/sendMessage`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    },
  );

  if (!res.ok) {
    const errText = await res.text();
    logger.error({ chatId, errText }, "Telegram sendMessage failed");
  }
}

// ─── Mini App URL ─────────────────────────────────────────────────────────────
// Replace with the actual published URL of your Telegram Mini App once deployed.
// During development you can use your Replit dev domain.

function getMiniAppUrl(): string {
  const domain =
    process.env["MINI_APP_URL"] ??
    `https://${process.env["REPLIT_DEV_DOMAIN"] ?? "localhost"}`;
  return domain;
}

// ─── Command handlers ─────────────────────────────────────────────────────────

async function handleStart(msg: TelegramMessage): Promise<void> {
  const firstName = msg.from?.first_name ?? "Player";
  const chatId = msg.chat.id;
  const miniAppUrl = getMiniAppUrl();

  const welcomeText =
    `🎱 <b>Welcome to Bingo ETB, ${firstName}!</b>\n\n` +
    `Play real-money bingo in two rooms:\n` +
    `• <b>5 ETB</b> room — casual stakes\n` +
    `• <b>10 ETB</b> room — bigger pot\n\n` +
    `Each card costs the room stake. Buy up to 3 cards per game.\n` +
    `Tap <b>Play Now</b> to open the app and join a game!`;

  await sendMessage(chatId, welcomeText, {
    inline_keyboard: [
      [
        {
          text: "🎰 Play Now",
          web_app: { url: miniAppUrl },
        },
      ],
    ],
  });
}

// ─── Router ───────────────────────────────────────────────────────────────────

const router: IRouter = Router();

// POST /api/bot/webhook — Telegram calls this for every update
router.post("/bot/webhook", async (req: Request, res: Response) => {
  // Acknowledge immediately — Telegram retries if we don't respond in ~5 s
  res.status(200).json({ ok: true });

  const update = req.body as TelegramUpdate;

  req.log.info({ update_id: update.update_id }, "Telegram update received");

  const msg = update.message;
  if (!msg?.text) return;

  const text = msg.text.trim();

  if (text.startsWith("/start")) {
    handleStart(msg).catch((err) =>
      logger.error({ err }, "/start handler failed"),
    );
    return;
  }

  // Unknown command — no response (keeps the bot quiet for unsupported commands)
});

// GET /api/bot/set-webhook — convenience endpoint to register the webhook URL
// Call once after deploying: GET /api/bot/set-webhook?url=https://yourdomain.com
router.get("/bot/set-webhook", async (req: Request, res: Response) => {
  const botToken = process.env["BOT_TOKEN"];
  if (!botToken) {
    res.status(500).json({ success: false, error: "BOT_TOKEN not configured" });
    return;
  }

  const webhookUrl =
    (req.query["url"] as string | undefined) ??
    `https://${process.env["REPLIT_DEV_DOMAIN"]}/api/bot/webhook`;

  const apiRes = await fetch(
    `https://api.telegram.org/bot${botToken}/setWebhook`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: webhookUrl, drop_pending_updates: true }),
    },
  );

  const data = (await apiRes.json()) as Record<string, unknown>;
  req.log.info({ webhookUrl, data }, "setWebhook called");
  res.status(200).json({ success: true, webhookUrl, telegram: data });
});

export default router;
