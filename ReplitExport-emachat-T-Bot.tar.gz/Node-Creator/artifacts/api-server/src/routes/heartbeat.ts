import { Router, type IRouter } from "express";
import { redis } from "../lib/redis";
import { supabase } from "../lib/supabase";

const router: IRouter = Router();

router.get("/heartbeat", async (req, res) => {
  const results: Record<string, { ok: boolean; latencyMs: number; error?: string }> = {};

  // Check Upstash Redis
  const redisStart = Date.now();
  try {
    await redis.ping();
    results.redis = { ok: true, latencyMs: Date.now() - redisStart };
  } catch (err) {
    req.log.error({ err }, "Redis heartbeat failed");
    results.redis = {
      ok: false,
      latencyMs: Date.now() - redisStart,
      error: err instanceof Error ? err.message : String(err),
    };
  }

  // Check Supabase
  const supabaseStart = Date.now();
  try {
    const { error } = await supabase.from("_heartbeat_probe").select("1").limit(1).maybeSingle();
    // A "table not found" error still means Supabase is reachable
    const isReachable =
      !error ||
      error.code === "42P01" ||
      error.message.includes("does not exist") ||
      error.message.includes("Could not find the table");
    if (isReachable) {
      results.supabase = { ok: true, latencyMs: Date.now() - supabaseStart };
    } else {
      results.supabase = {
        ok: false,
        latencyMs: Date.now() - supabaseStart,
        error: error.message,
      };
    }
  } catch (err) {
    req.log.error({ err }, "Supabase heartbeat failed");
    results.supabase = {
      ok: false,
      latencyMs: Date.now() - supabaseStart,
      error: err instanceof Error ? err.message : String(err),
    };
  }

  const allOk = Object.values(results).every((r) => r.ok);

  res.status(allOk ? 200 : 503).json({
    status: allOk ? "ok" : "degraded",
    timestamp: new Date().toISOString(),
    services: results,
  });
});

export default router;
