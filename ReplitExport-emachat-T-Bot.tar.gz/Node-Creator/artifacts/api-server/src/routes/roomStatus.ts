import { Router, type IRouter } from "express";
import { redis } from "../lib/redis";
import { authMiddleware } from "../middleware/authMiddleware";
import { getRoomMeta, getSoldCardIds, type RoomId } from "../services/roomManager";

const router: IRouter = Router();

const VALID_ROOMS: RoomId[] = ["10etb", "5etb"];

router.get("/room-status/:room", authMiddleware, async (req, res) => {
  const { room } = req.params;

  if (!VALID_ROOMS.includes(room as RoomId)) {
    res.status(400).json({
      success: false,
      error: `room must be one of: ${VALID_ROOMS.join(", ")}`,
    });
    return;
  }

  const typedRoom = room as RoomId;

  try {
    // 1. Check for lobby state first (highest priority)
    const lobbyEndsAtRaw = await redis.get<string>(
      `room:${typedRoom}:lobby_ends_at`,
    );

    if (lobbyEndsAtRaw) {
      const lobbyEndsAt = parseInt(lobbyEndsAtRaw, 10);
      const now = Date.now();
      const lobbyCountdown = Math.max(0, Math.round((lobbyEndsAt - now) / 1000));

      res.status(200).json({
        success: true,
        room: typedRoom,
        status: "lobby",
        lobby_countdown: lobbyCountdown,
        lobby_ends_at: lobbyEndsAt,
        current_batch: null,
        cards_sold: 0,
        sold_card_ids: [],
        pot: 0,
        winner_prize: 0,
      });
      return;
    }

    // 2. Fetch meta and sold cards in parallel
    const [meta, soldCardIds] = await Promise.all([
      getRoomMeta(typedRoom),
      getSoldCardIds(typedRoom),
    ]);

    if (!meta) {
      res.status(200).json({
        success: true,
        room: typedRoom,
        status: "idle",
        lobby_countdown: null,
        lobby_ends_at: null,
        current_batch: null,
        cards_sold: 0,
        sold_card_ids: [],
        pot: 0,
        winner_prize: 0,
      });
      return;
    }

    res.status(200).json({
      success: true,
      room: typedRoom,
      status: "active",
      lobby_countdown: null,
      lobby_ends_at: null,
      current_batch: meta.batch_id,
      cards_sold: meta.card_count,
      sold_card_ids: soldCardIds.sort((a, b) => a - b),
      pot: meta.pot,
      winner_prize: meta.winner_prize,
    });
  } catch (err: unknown) {
    req.log.error({ err, room }, "room-status failed");
    const message = err instanceof Error ? err.message : String(err);
    res.status(500).json({ success: false, error: message });
  }
});

export default router;
