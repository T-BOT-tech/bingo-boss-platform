import { readFileSync } from "fs";
import { join } from "path";
import { supabase } from "../lib/supabase";
import { redis } from "../lib/redis";
import { logger } from "../lib/logger";
import {
  eventBus,
  type BallDrawnPayload,
  type GameCompletePayload,
} from "../lib/eventBus";
import { getIO } from "../lib/socket";
import {
  getRoomMeta,
  getPlayerCardsMap,
  acquirePayoutLock,
  endGame,
  type RoomId,
} from "./roomManager";

// ─── Card data & indexes ──────────────────────────────────────────────────────

interface CardEntry {
  id: number;
  batch: string;
  numbers: number[]; // 25 elements, row-major; index 12 = 0 (FREE)
}

// Load cards from the static JSON file (bundled via esbuild or read from src/)
function loadCards(): CardEntry[] {
  try {
    // Works in dev (run from artifacts/api-server) and in esbuild bundle
    // (esbuild sets __dirname to the bundle directory, which has the file copied)
    const raw = readFileSync(
      join(process.cwd(), "src/data/cards.json"),
      "utf-8",
    );
    return (JSON.parse(raw) as { cards: CardEntry[] }).cards;
  } catch {
    // Fallback path for built bundle
    const raw = readFileSync(
      join(__dirname, "../src/data/cards.json"),
      "utf-8",
    );
    return (JSON.parse(raw) as { cards: CardEntry[] }).cards;
  }
}

const ALL_CARDS = loadCards();

// cardId → numbers[]
const cardMap = new Map<number, number[]>(
  ALL_CARDS.map((c) => [c.id, c.numbers]),
);

// ball (1-75) → cardIds that contain it (built once at startup)
const invertedIndex = new Map<number, number[]>();
for (const card of ALL_CARDS) {
  for (const num of card.numbers) {
    if (num === 0) continue; // skip FREE
    if (!invertedIndex.has(num)) invertedIndex.set(num, []);
    invertedIndex.get(num)!.push(card.id);
  }
}

logger.info(
  { cards: ALL_CARDS.length, indexKeys: invertedIndex.size },
  "Inverted index built",
);

// ─── Bingo patterns (row-major 5×5) ──────────────────────────────────────────

const BINGO_PATTERNS: number[][] = [
  // Rows
  [0, 1, 2, 3, 4],
  [5, 6, 7, 8, 9],
  [10, 11, 12, 13, 14],
  [15, 16, 17, 18, 19],
  [20, 21, 22, 23, 24],
  // Columns
  [0, 5, 10, 15, 20],
  [1, 6, 11, 16, 21],
  [2, 7, 12, 17, 22],
  [3, 8, 13, 18, 23],
  [4, 9, 14, 19, 24],
  // Diagonals
  [0, 6, 12, 18, 24],
  [4, 8, 12, 16, 20],
];

function hasBingo(numbers: number[], drawnSet: Set<number>): boolean {
  return BINGO_PATTERNS.some((pattern) =>
    pattern.every((idx) => numbers[idx] === 0 || drawnSet.has(numbers[idx])),
  );
}

// ─── In-memory drawn-ball state ───────────────────────────────────────────────

const drawnBalls = new Map<RoomId, Set<number>>([
  ["10etb", new Set()],
  ["5etb", new Set()],
]);

export function resetDrawnBalls(room: RoomId): void {
  drawnBalls.get(room)?.clear();
}

// ─── Payout logic ─────────────────────────────────────────────────────────────

interface WinnerEntry {
  userId: number;  // BIGINT — numeric Telegram ID
  cardId: number;
  amountWon: number;
}

async function processPayout(
  room: RoomId,
  gameId: string,
  winnerPrize: number,
  winningCardIds: number[],
  playerCardsMap: Map<string, number[]>,
): Promise<void> {
  // Build card → owner map
  const cardOwner = new Map<number, string>();
  for (const [userId, cardIds] of playerCardsMap) {
    for (const cid of cardIds) cardOwner.set(cid, userId);
  }

  const totalWinningCards = winningCardIds.length;
  const prizePerCard = winnerPrize / totalWinningCards;

  // Group winnings per player (one player may own multiple winning cards)
  const payoutMap = new Map<string, { cardIds: number[]; total: number }>();
  for (const cardId of winningCardIds) {
    const userId = cardOwner.get(cardId);
    if (!userId) continue;
    const entry = payoutMap.get(userId) ?? { cardIds: [], total: 0 };
    entry.cardIds.push(cardId);
    entry.total += prizePerCard;
    payoutMap.set(userId, entry);
  }

  const winners: WinnerEntry[] = [];

  for (const [userIdStr, { cardIds, total }] of payoutMap) {
    // payoutMap keys come from Redis SMEMBERS which always returns strings.
    // Parse to number for Supabase BIGINT (profiles.id) queries.
    // Template literals handle both: `user:${numericId}` === `user:${userIdStr}`.
    const numericUserId = parseInt(userIdStr, 10);

    // Credit balance: read then write (lock ensures single execution)
    try {
      const { data: profile } = await supabase
        .from("profiles")
        .select("balance_etb")
        .eq("id", numericUserId)
        .single();

      const balanceBefore = Number(profile?.balance_etb ?? 0);
      const balanceAfter = balanceBefore + total;

      await supabase
        .from("profiles")
        .update({ balance_etb: balanceAfter })
        .eq("id", numericUserId);

      // Write an immutable win transaction record to the ledger
      try {
        await supabase.from("transactions").insert({
          user_id: numericUserId,
          type: "win",
          amount: total,
          balance_before: balanceBefore,
          balance_after: balanceAfter,
          description:
            `Bingo win in ${room} room` +
            (totalWinningCards > 1 ? ` (split pot, ${totalWinningCards} winners)` : ""),
          reference_id: gameId,
          created_at: new Date().toISOString(),
        });
      } catch (ledgerErr) {
        logger.warn({ ledgerErr, numericUserId }, "transactions insert failed");
      }

      // Record in game_history (table may not exist yet — wrapped in try-catch)
      try {
        for (const cardId of cardIds) {
          await supabase.from("game_history").insert({
            user_id: numericUserId,
            room,
            game_id: gameId,
            card_id: cardId,
            amount_won: prizePerCard,
            total_won: total,
            is_split: totalWinningCards > 1,
            winner_count: totalWinningCards,
            created_at: new Date().toISOString(),
          });
        }
      } catch (histErr) {
        logger.warn({ histErr, numericUserId }, "game_history insert failed");
      }

      // Push a real-time balance update to the winner's connected device.
      // Room name uses the numeric ID to match what the client sets up via
      // socket.emit("join_user_room", String(telegramUser.id))
      try {
        getIO().to(`user:${numericUserId}`).emit("balance_update", {
          type: "balance_update",
          userId: numericUserId,
          balance_etb: balanceAfter,
          delta: total,
          reason: "win",
          room,
          game_id: gameId,
          timestamp: Date.now(),
        });
      } catch (sockErr) {
        logger.warn({ sockErr, numericUserId }, "balance_update emit failed");
      }

      for (const cardId of cardIds) {
        winners.push({ userId: numericUserId, cardId, amountWon: prizePerCard });
      }

      logger.info({ room, numericUserId, cardIds, total, balanceAfter }, "Payout credited");
    } catch (payErr) {
      logger.error({ room, numericUserId: userIdStr, payErr }, "Payout credit failed");
    }
  }

  // Signal the dealer to stop the current draw loop immediately
  eventBus.emit("winner_found", { room });

  // Broadcast GAME_OVER via Socket.io
  try {
    getIO().emit(`${room}:events`, {
      type: "GAME_OVER",
      gameId,
      winners,
      totalWinningCards,
      prizePerCard,
      totalPrize: winnerPrize,
      timestamp: Date.now(),
    });
    logger.info({ room, winners: winners.length }, "GAME_OVER emitted");
  } catch (sockErr) {
    logger.error({ sockErr }, "Socket.IO emit failed");
  }

  // Reset room and release batch
  await endGame(room);
  resetDrawnBalls(room);
}

// ─── Ball-draw handler ────────────────────────────────────────────────────────

async function onBallDrawn({ room, ball }: BallDrawnPayload): Promise<void> {
  const roomDrawn = drawnBalls.get(room)!;
  roomDrawn.add(ball);

  // Find candidate cards (only those containing this ball — O(k) not O(n))
  const candidates = invertedIndex.get(ball) ?? [];
  if (candidates.length === 0) return;

  // Check each candidate for bingo
  const winningCardIds: number[] = [];
  for (const cardId of candidates) {
    const numbers = cardMap.get(cardId);
    if (numbers && hasBingo(numbers, roomDrawn)) {
      winningCardIds.push(cardId);
    }
  }

  if (winningCardIds.length === 0) return;

  // ── Winners found — acquire the payout lock BEFORE processing ────────────
  const meta = await getRoomMeta(room);
  if (!meta) return; // Room already cleaned up

  const lockAcquired = await acquirePayoutLock(room, meta.game_id);
  if (!lockAcquired) {
    logger.warn({ room }, "Payout lock already held — skipping duplicate");
    return;
  }

  logger.info(
    { room, ball, winningCardIds, winnerPrize: meta.winner_prize },
    "BINGO detected — lock acquired, processing payout",
  );

  // Fetch player→cards map after confirming winners (ensures split-winners all captured)
  const playerCardsMap = await getPlayerCardsMap(room);

  await processPayout(
    room,
    meta.game_id,
    meta.winner_prize,
    winningCardIds,
    playerCardsMap,
  );

  // Publish winner event to Redis pub/sub for any external subscribers
  await redis.publish(
    `${room}:events`,
    JSON.stringify({
      type: "BINGO",
      winningCardIds,
      timestamp: Date.now(),
    }),
  );
}

// ─── No-winner game-over handler ──────────────────────────────────────────────

async function onGameComplete({ room }: GameCompletePayload): Promise<void> {
  const meta = await getRoomMeta(room);
  if (!meta) return; // Already cleaned up (winner was found mid-game)

  // Try to acquire lock — if the monitor already paid out, this is a no-op
  const lockAcquired = await acquirePayoutLock(room, meta.game_id);
  if (!lockAcquired) {
    logger.info({ room }, "No-winner end: lock already held, skipping");
    return;
  }

  logger.info({ room }, "No winner — emitting GAME_OVER and resetting room");

  try {
    getIO().emit(`${room}:events`, {
      type: "GAME_OVER",
      gameId: meta.game_id,
      winners: [],
      totalWinningCards: 0,
      prizePerCard: 0,
      totalPrize: 0,
      timestamp: Date.now(),
    });
  } catch (sockErr) {
    logger.error({ sockErr }, "Socket.IO emit failed");
  }

  await endGame(room);
  resetDrawnBalls(room);
}

// ─── Public init ──────────────────────────────────────────────────────────────

export function startMonitor(): void {
  eventBus.on("ball_drawn", (payload: BallDrawnPayload) => {
    onBallDrawn(payload).catch((err) =>
      logger.error({ err }, "Monitor ball handler crashed"),
    );
  });

  eventBus.on("game_complete", (payload: GameCompletePayload) => {
    onGameComplete(payload).catch((err) =>
      logger.error({ err }, "Monitor game-complete handler crashed"),
    );
  });

  logger.info("Winner monitor started");
}
