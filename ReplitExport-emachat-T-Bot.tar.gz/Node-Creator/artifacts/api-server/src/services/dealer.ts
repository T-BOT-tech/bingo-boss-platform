import { redis } from "../lib/redis";
import { logger } from "../lib/logger";
import { getIO } from "../lib/socket";
import { type RoomId } from "./roomManager";
import { eventBus, type WinnerFoundPayload } from "../lib/eventBus";

// ─── Constants ────────────────────────────────────────────────────────────────

const DRAW_INTERVAL_MS = 2500;
const LOBBY_DURATION_S = 20;

// ─── Lua atomic draw ──────────────────────────────────────────────────────────
// One round-trip: SPOP a random ball from the pool SET and SETBIT it in the
// history bitfield. Returns the ball number (1-75) or -1 when pool is empty.

const LUA_DRAW = `
local ball = redis.call('SPOP', KEYS[1])
if ball == false then
  return -1
end
local n = tonumber(ball)
redis.call('SETBIT', KEYS[2], n, 1)
return n
`;

// ─── Helpers ──────────────────────────────────────────────────────────────────

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function lobbyKey(room: RoomId) {
  return `room:${room}:lobby_ends_at`;
}
function poolKey(room: RoomId) {
  return `room:${room}:pool`;
}
function drawnBitsKey(room: RoomId) {
  return `room:${room}:drawn_bits`;
}

// ─── Lobby phase ──────────────────────────────────────────────────────────────

async function runLobby(room: RoomId): Promise<void> {
  const lobbyEndsAt = Date.now() + LOBBY_DURATION_S * 1000;

  // Persist lobby state so room-status can show a countdown
  await redis.set(lobbyKey(room), String(lobbyEndsAt), {
    ex: LOBBY_DURATION_S + 5,
  });

  logger.info({ room, lobbyEndsAt }, "Lobby started");

  for (let countdown = LOBBY_DURATION_S; countdown >= 0; countdown--) {
    const event = {
      type: "LOBBY_COUNTDOWN",
      countdown,
      lobby_ends_at: lobbyEndsAt,
      timestamp: Date.now(),
    };
    const payload = JSON.stringify(event);

    // Broadcast via Redis pub/sub (external subscribers)
    await redis.publish(`${room}:events`, payload);

    // Broadcast via Socket.io (connected Telegram Mini App clients)
    try {
      getIO().emit(`${room}:events`, event);
    } catch {
      // Socket.io may not be ready on very first lobby — safe to ignore
    }

    if (countdown > 0) await delay(1000);
  }

  await redis.del(lobbyKey(room));
  logger.info({ room }, "Lobby ended — starting new game");
}

// ─── Game phase ───────────────────────────────────────────────────────────────

async function runGame(room: RoomId): Promise<void> {
  logger.info({ room }, "Game started");

  const pKey = poolKey(room);
  const dKey = drawnBitsKey(room);

  // Reset keys from any previous game
  await redis.del(pKey, dKey);
  const balls = Array.from({ length: 75 }, (_, i) => i + 1);
  await redis.sadd(pKey, ...(balls as [number, ...number[]]));

  let gameEnded = false;

  // Stop the draw loop as soon as the monitor finds a winner
  const onWinnerFound = ({ room: r }: WinnerFoundPayload) => {
    if (r === room) gameEnded = true;
  };
  eventBus.on("winner_found", onWinnerFound);

  try {
    while (!gameEnded) {
      await delay(DRAW_INTERVAL_MS);

      if (gameEnded) break; // Winner found while we were waiting

      // Atomic: SPOP pool + SETBIT history in one Lua round-trip
      const ball = (await redis.eval(LUA_DRAW, [pKey, dKey], [])) as number;

      if (ball === null || ball === -1) {
        // All 75 balls exhausted — no winner this game
        logger.info({ room }, "All 75 balls drawn — no winner");
        eventBus.emit("game_complete", { room });
        break;
      }

      // Notify in-process monitor for winner detection
      eventBus.emit("ball_drawn", { room, ball });

      // Broadcast to external pub/sub subscribers
      await redis.publish(
        `${room}:events`,
        JSON.stringify({ type: "BALL_DRAWN", value: ball, timestamp: Date.now() }),
      );

      logger.info({ room, ball }, "Ball drawn");
    }
  } finally {
    eventBus.off("winner_found", onWinnerFound);
  }
}

// ─── Dealer loop (per room) ───────────────────────────────────────────────────

async function startDealer(room: RoomId): Promise<void> {
  logger.info({ room }, "Dealer started");

  // First game starts immediately (no lobby on cold boot)
  await runGame(room);

  // Subsequent games always have a 20-second lobby between them
  while (true) {
    await runLobby(room);
    await runGame(room);
  }
}

// ─── Boot both rooms ──────────────────────────────────────────────────────────

export async function startDealers(): Promise<void> {
  // Run both rooms concurrently and independently — do not await together
  // (if one crashes the other keeps going)
  startDealer("10etb").catch((err) =>
    logger.error({ err, room: "10etb" }, "10etb dealer crashed"),
  );
  startDealer("5etb").catch((err) =>
    logger.error({ err, room: "5etb" }, "5etb dealer crashed"),
  );
}
