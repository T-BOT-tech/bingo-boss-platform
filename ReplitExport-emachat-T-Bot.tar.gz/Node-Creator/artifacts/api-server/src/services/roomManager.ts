import { redis } from "../lib/redis";
import { logger } from "../lib/logger";

// ─── Types ───────────────────────────────────────────────────────────────────

export type BatchId = "A" | "B" | "C";
export type RoomId = "10etb" | "5etb";

export interface RoomMeta {
  batch_id: BatchId;
  game_id: string;
  card_count: number;
  pot: number;
  winner_prize: number;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const BATCHES: BatchId[] = ["A", "B", "C"];
const BATCH_RANGES: Record<BatchId, [number, number]> = {
  A: [1, 500],
  B: [501, 1000],
  C: [1001, 1500],
};
const ROOM_META_TTL = 3600; // 1 hour
const COMMISSION_RATE = 0.2; // 20% house cut → 80% to winner
const MAX_CARDS_PER_BATCH = 500;

// Redis key helpers
const K = {
  batchStatus: () => "batches:status",
  batchRoomMap: () => "batches:room_to_batch",
  roomMeta: (room: RoomId) => `room:${room}:meta`,
  nextGamePlayers: (room: RoomId) => `room:${room}:next_game:players`,
  nextGameCards: (room: RoomId, userId: string) =>
    `room:${room}:next_game:player:${userId}:cards`,
  payoutLock: (room: RoomId, gameId: string) =>
    `payout_lock:${room}:${gameId}`,
};

// ─── Batch helpers ────────────────────────────────────────────────────────────

export function getCardBatch(cardId: number): BatchId {
  if (cardId >= BATCH_RANGES.A[0] && cardId <= BATCH_RANGES.A[1]) return "A";
  if (cardId >= BATCH_RANGES.B[0] && cardId <= BATCH_RANGES.B[1]) return "B";
  return "C";
}

export function validateCardsForBatch(
  cardIds: number[],
  batchId: BatchId,
): boolean {
  return cardIds.every((id) => getCardBatch(id) === batchId);
}

// ─── Batch pool ───────────────────────────────────────────────────────────────

async function initBatchPool(): Promise<void> {
  const existing = await redis.hget<string>(K.batchStatus(), "A");
  if (!existing) {
    await redis.hset(K.batchStatus(), { A: "clean", B: "clean", C: "clean" });
    logger.info("Batch pool initialised (A/B/C all clean)");
  }
}

async function assignBatch(room: RoomId): Promise<BatchId> {
  const otherRoom: RoomId = room === "10etb" ? "5etb" : "10etb";
  const otherBatch = await redis.hget<string>(K.batchRoomMap(), otherRoom);
  const statuses = await redis.hgetall<Record<string, string>>(K.batchStatus());

  for (const batch of BATCHES) {
    if (statuses?.[batch] === "clean" && batch !== otherBatch) {
      await redis.hset(K.batchStatus(), { [batch]: "in_use" });
      await redis.hset(K.batchRoomMap(), { [room]: batch });
      logger.info({ room, batch }, "Batch assigned to room");
      return batch;
    }
  }

  throw new Error(`No clean batch available for room ${room}`);
}

// ─── Room meta ────────────────────────────────────────────────────────────────

async function parseRoomMeta(
  raw: Record<string, string> | null,
): Promise<RoomMeta | null> {
  if (!raw || !raw.batch_id) return null;
  return {
    batch_id: raw.batch_id as BatchId,
    game_id: raw.game_id ?? "",
    card_count: parseInt(raw.card_count ?? "0", 10),
    pot: parseFloat(raw.pot ?? "0"),
    winner_prize: parseFloat(raw.winner_prize ?? "0"),
  };
}

export async function getRoomMeta(room: RoomId): Promise<RoomMeta | null> {
  const raw = await redis.hgetall<Record<string, string>>(K.roomMeta(room));
  return parseRoomMeta(raw);
}

export async function getOrInitRoom(room: RoomId): Promise<RoomMeta> {
  await initBatchPool();

  const existing = await getRoomMeta(room);
  if (existing) return existing;

  const batchId = await assignBatch(room);
  const game_id = `${room}-${Date.now()}`;

  await redis.hset(K.roomMeta(room), {
    batch_id: batchId,
    game_id,
    card_count: "0",
    pot: "0",
    winner_prize: "0",
  });
  await redis.expire(K.roomMeta(room), ROOM_META_TTL);

  return { batch_id: batchId, game_id, card_count: 0, pot: 0, winner_prize: 0 };
}

// ─── Join registration ────────────────────────────────────────────────────────

export async function registerJoin(
  room: RoomId,
  userId: string,
  cardIds: number[],
  stake: number,
): Promise<{ card_count: number; pot: number; winner_prize: number }> {
  const totalCost = stake * cardIds.length;
  const metaKey = K.roomMeta(room);

  const pipeline = redis.pipeline();
  pipeline.sadd(K.nextGamePlayers(room), userId);
  pipeline.set(K.nextGameCards(room, userId), JSON.stringify(cardIds));
  pipeline.hincrbyfloat(metaKey, "pot", totalCost);
  pipeline.hincrby(metaKey, "card_count", cardIds.length);
  pipeline.expire(metaKey, ROOM_META_TTL); // refresh TTL on every join
  await pipeline.exec();

  // Read back the updated meta to compute winner_prize
  const raw = await redis.hgetall<Record<string, string>>(metaKey);
  const pot = parseFloat(raw?.pot ?? "0");
  const card_count = parseInt(raw?.card_count ?? "0", 10);
  const winner_prize = pot * (1 - COMMISSION_RATE);

  // Persist computed prize back to meta
  await redis.hset(metaKey, { winner_prize: String(winner_prize) });

  // Warn when batch is at capacity — next game will rotate
  if (card_count >= MAX_CARDS_PER_BATCH) {
    logger.warn(
      { room, card_count },
      "Batch capacity reached — will rotate on next game",
    );
  }

  return { card_count, pot, winner_prize };
}

// ─── Sold card lookup ─────────────────────────────────────────────────────────

export async function getSoldCardIds(room: RoomId): Promise<number[]> {
  const players = await redis.smembers<string[]>(K.nextGamePlayers(room));
  if (!players || players.length === 0) return [];

  // Fetch every player's card list in one pipeline pass
  const pipeline = redis.pipeline();
  for (const userId of players) {
    pipeline.get<string>(K.nextGameCards(room, userId));
  }
  const results = await pipeline.exec();

  const soldIds: number[] = [];
  for (const raw of results as (string | null)[]) {
    if (raw) {
      const ids = JSON.parse(raw) as number[];
      soldIds.push(...ids);
    }
  }
  return soldIds;
}

// ─── Player → cards mapping (for winner attribution) ─────────────────────────

export async function getPlayerCardsMap(
  room: RoomId,
): Promise<Map<string, number[]>> {
  const players = await redis.smembers<string[]>(K.nextGamePlayers(room));
  if (!players || players.length === 0) return new Map();

  const pipeline = redis.pipeline();
  for (const userId of players) {
    pipeline.get<string>(K.nextGameCards(room, userId));
  }
  const results = await pipeline.exec();

  const map = new Map<string, number[]>();
  players.forEach((userId, i) => {
    const raw = (results as (string | null)[])[i];
    if (raw) map.set(userId, JSON.parse(raw) as number[]);
  });
  return map;
}

// ─── Payout lock (idempotency) ────────────────────────────────────────────────

export async function acquirePayoutLock(
  room: RoomId,
  gameId: string,
): Promise<boolean> {
  // SET NX EX 60 — only one process wins, lock expires after 60s
  const result = await redis.set(K.payoutLock(room, gameId), "1", {
    nx: true,
    ex: 60,
  });
  return result === "OK";
}

// ─── End game / batch return ──────────────────────────────────────────────────

export async function endGame(room: RoomId): Promise<void> {
  const batchId = await redis.hget<string>(K.batchRoomMap(), room);

  if (batchId) {
    await redis.hset(K.batchStatus(), { [batchId]: "clean" });
    await redis.hdel(K.batchRoomMap(), room);
    logger.info({ room, batchId }, "Batch returned to clean pool");
  }

  // Clean up room state
  await redis.del(K.roomMeta(room));
  await redis.del(K.nextGamePlayers(room));
  logger.info({ room }, "Room reset for next game");
}
