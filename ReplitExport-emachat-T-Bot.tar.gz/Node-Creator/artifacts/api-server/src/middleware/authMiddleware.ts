import type { Request, Response, NextFunction } from "express";
import { supabase } from "../lib/supabase";
import { logger } from "../lib/logger";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
}

// Extend Express Request so downstream handlers get typed user info
declare global {
  namespace Express {
    interface Request {
      telegramUser: TelegramUser;
    }
  }
}

// ─── HMAC-SHA256 via Web Crypto ───────────────────────────────────────────────

async function hmacSha256(key: CryptoKey, data: string): Promise<ArrayBuffer> {
  const enc = new TextEncoder();
  return crypto.subtle.sign("HMAC", key, enc.encode(data));
}

function bufToHex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function importKey(raw: string, algo: string): Promise<CryptoKey> {
  return crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(raw),
    { name: "HMAC", hash: algo },
    false,
    ["sign"],
  );
}

// ─── Telegram initData validation ─────────────────────────────────────────────
// Spec: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app

async function validateInitData(initData: string): Promise<TelegramUser> {
  const botToken = process.env["BOT_TOKEN"];
  if (!botToken) throw new Error("BOT_TOKEN is not configured");

  const params = new URLSearchParams(initData);
  const receivedHash = params.get("hash");
  if (!receivedHash) throw new Error("initData missing hash");

  // Build the data-check string: all fields except 'hash', sorted, joined with \n
  params.delete("hash");
  const dataCheckString = Array.from(params.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join("\n");

  // secret_key = HMAC-SHA256("WebAppData", bot_token)
  const webAppDataKey = await importKey("WebAppData", "SHA-256");
  const secretKeyBuf = await hmacSha256(webAppDataKey, botToken);

  // Import the derived secret key
  const secretKey = await crypto.subtle.importKey(
    "raw",
    secretKeyBuf,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );

  // Compute expected hash
  const expectedHashBuf = await hmacSha256(secretKey, dataCheckString);
  const expectedHash = bufToHex(expectedHashBuf);

  if (expectedHash !== receivedHash) {
    throw new Error("initData HMAC validation failed");
  }

  // Check auth_date is not stale (reject data older than 1 hour)
  const authDate = Number(params.get("auth_date") ?? "0");
  if (!authDate) throw new Error("initData missing auth_date");
  const ageSeconds = Math.floor(Date.now() / 1000) - authDate;
  if (ageSeconds > 3600) {
    throw new Error(`initData expired (age: ${ageSeconds}s)`);
  }

  // Decode user object
  const userRaw = params.get("user");
  if (!userRaw) throw new Error("initData missing user field");

  let user: TelegramUser;
  try {
    user = JSON.parse(userRaw) as TelegramUser;
  } catch {
    throw new Error("initData user field is invalid JSON");
  }

  if (!user.id) throw new Error("initData user.id is missing");
  return user;
}

// ─── User sync ────────────────────────────────────────────────────────────────
// Upserts a row in `profiles` (id=telegram_user_id) with a starting balance of 0.
// Uses upsert so it's idempotent on every launch.

async function syncUser(user: TelegramUser): Promise<void> {
  const { error } = await supabase.from("profiles").upsert(
    {
      // profiles.id is BIGINT — pass the numeric Telegram user ID directly.
      // Never stringify: "123456789" would insert as TEXT and mismatch the PK.
      id: user.id,
      first_name: user.first_name,
      username: user.username ?? null,
      balance_etb: 0,
    },
    {
      onConflict: "id",
      // Only update name/username, never overwrite balance on re-launch
      ignoreDuplicates: false,
    },
  );

  if (error) {
    // Non-fatal — user already exists or table not yet migrated
    logger.warn({ error, userId: user.id }, "Profile upsert warning");
  }
}

// ─── Middleware ───────────────────────────────────────────────────────────────

export async function authMiddleware(
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const initData =
    req.headers["x-telegram-init-data"] ??
    (req.body as Record<string, string>)?.initData;

  if (!initData || typeof initData !== "string") {
    res.status(401).json({
      success: false,
      error: "Missing Telegram initData. Pass it in the X-Telegram-Init-Data header.",
    });
    return;
  }

  try {
    const user = await validateInitData(initData);
    await syncUser(user);
    req.telegramUser = user;
    next();
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    logger.warn({ message }, "Auth rejected");
    res.status(403).json({ success: false, error: message });
  }
}
