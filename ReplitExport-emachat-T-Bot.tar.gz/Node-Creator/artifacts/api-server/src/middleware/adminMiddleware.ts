import type { Request, Response, NextFunction } from "express";
import { createHmac } from "crypto";
import { timingSafeEqual } from "crypto";

// Timing-safe string comparison: hashes both values with a fixed key so the
// buffer lengths are always equal, preventing length-based timing leaks.
function safeCompare(a: string, b: string): boolean {
  const sign = (v: string) =>
    createHmac("sha256", "admincheck").update(v).digest();
  return timingSafeEqual(sign(a), sign(b));
}

export function adminMiddleware(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const adminSecret = process.env["ADMIN_SECRET"];
  if (!adminSecret) {
    // Fail closed: if the secret is not configured, nobody gets in
    res
      .status(503)
      .json({ success: false, error: "Admin secret is not configured" });
    return;
  }

  const provided =
    (req.headers["x-admin-secret"] as string | undefined) ?? "";

  if (!provided || !safeCompare(provided, adminSecret)) {
    res.status(403).json({ success: false, error: "Forbidden" });
    return;
  }

  next();
}
