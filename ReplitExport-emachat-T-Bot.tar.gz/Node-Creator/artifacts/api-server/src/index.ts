import { createServer } from "http";
import app from "./app";
import { logger } from "./lib/logger";
import { initSocket } from "./lib/socket";
import { startDealers } from "./services/dealer";
import { startMonitor } from "./services/monitor";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const httpServer = createServer(app);

// Attach Socket.io to the HTTP server (must happen before listen)
initSocket(httpServer);

httpServer.on("error", (err) => {
  logger.error({ err }, "Server error");
  process.exit(1);
});

httpServer.listen(port, () => {
  logger.info({ port }, "Server listening");

  // Start winner monitor first (must be ready before dealers emit events)
  startMonitor();

  // Start the Dual-Room ball draw loops
  startDealers().catch((dealerErr) => {
    logger.error({ err: dealerErr }, "Failed to start dealers");
  });
});
