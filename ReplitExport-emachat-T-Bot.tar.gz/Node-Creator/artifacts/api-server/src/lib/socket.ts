import { Server as SocketServer } from "socket.io";
import type { Server as HttpServer } from "http";
import { logger } from "./logger";

let _io: SocketServer | null = null;

export function initSocket(httpServer: HttpServer): SocketServer {
  _io = new SocketServer(httpServer, {
    cors: { origin: "*" },
  });

  _io.on("connection", (socket) => {
    // Clients call this once on connect, passing their Telegram user ID.
    // Always send it as a string from the client side to avoid JSON BigInt issues:
    //   socket.emit("join_user_room", String(telegramUser.id))
    // The server names the room user:{id} matching the numeric ID used by the monitor.
    socket.on("join_user_room", (userId: unknown) => {
      if (typeof userId === "string" && userId.length > 0 && userId.length < 64) {
        // Normalise: strip any non-digit characters and re-stringify for room safety
        const normalised = String(parseInt(userId, 10));
        socket.join(`user:${normalised}`);
        logger.info({ userId, socketId: socket.id }, "Socket joined user room");
      }
    });

    socket.on("disconnect", () => {
      logger.info({ socketId: socket.id }, "Socket disconnected");
    });
  });

  return _io;
}

export function getIO(): SocketServer {
  if (!_io) throw new Error("Socket.IO not initialized");
  return _io;
}
