import { EventEmitter } from "events";
import type { RoomId } from "../services/roomManager";

export interface BallDrawnPayload {
  room: RoomId;
  ball: number;
}

export interface GameCompletePayload {
  room: RoomId;
}

export interface WinnerFoundPayload {
  room: RoomId;
}

class GameEventBus extends EventEmitter {}

export const eventBus = new GameEventBus();
